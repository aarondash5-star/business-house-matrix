# Delulu Tech — Wordmark Geometry Freeze v1.0

**Status:** logo shape geometry frozen as of 2026-10-24.
**Chosen concept:** Impossible Ribbon, Option #2.
**Brand spelling:** `delulu TECH` (lowercase delulu, secondary uppercase TECH).

## Final files
- `delulu-tech-wordmark-black.svg` — full-size canonical wordmark, black on transparent.
- `delulu-tech-wordmark-white.svg` — full-size inverse on transparent.
- `delulu-tech-mobile-black.svg` — mobile lockup, TECH scaled up ~35% to preserve readability.
- `delulu-tech-mobile-white.svg` — inverse mobile variant.
- Matching transparent 160, 200, 400, 1000px PNGs, plus `delulu-mobile-QA-final.png`.

## Rules / checks
- Font-independent vector paths from approved original artwork; fill-rule evenodd retains counters and impossible-ribbon negative spaces.
- Primary identity must remain exactly `delulu TECH`, no icon.
- For header width 160–200px use **mobile** SVG variant; avoid rendering full wordmark smaller than 160px wide.
- Black `#111111` and white `#ffffff` are temporary neutral masters, **not** final brand palette.
- Visual QA performed at 160 and 200px plus inverse on dark; source concept preserved.
- Do not merge more overlaps or shrink TECH during animation.

## Not included
Color palette, animation, homepage wireframe, trademark clearance, user approval of final production styling. These follow the brand decision sequence.
